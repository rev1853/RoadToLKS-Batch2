﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramworkPart2
{
    class Class1
    {
        static public int id = 0;
    }
}
